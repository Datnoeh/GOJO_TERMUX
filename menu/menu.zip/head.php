<?php
echo"\e[1;32mMENU NETBANS JAR
\e[1;31mBy datbao
Cre KhanhNguyen9872

\e[1;33mVersion: 1
";
?> 