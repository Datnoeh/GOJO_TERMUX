<?php
$data_server ="dat";
   $menu = 0;
$version = 8;
?>