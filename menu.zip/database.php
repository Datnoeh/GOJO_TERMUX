<?php
$data_server ="datvip";
   $menu = 0;
$version = 7;
?>