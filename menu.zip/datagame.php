<?php
$name ="datviptoi";
$exe = 100;
?>