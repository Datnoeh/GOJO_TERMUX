<?php
$name ="idkdkx";
$exe = 394;
?>