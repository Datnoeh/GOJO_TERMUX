<?php
$ip ="127.0.0.1:14445";

   $exe = "100";
$name_sv = "Datsiuu";
?>