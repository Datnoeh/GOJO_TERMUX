<?php
$ip ="jfjfjfjf";

   $exe = "444";
$name_sv = "jfjfjfjf";
?>